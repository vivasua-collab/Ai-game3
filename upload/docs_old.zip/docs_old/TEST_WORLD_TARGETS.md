# 🎯 Тестовый мир: Полигон и мишени

**Версия:** 1.0  
**Создано:** 2026-02-12  
**Статус:** Реализация

---

## 📋 Обзор

Тестовый полигон для отработки боевых техник. Включает:
- Управляемого персонажа с направлением взгляда
- Статичные мишени (соломенные чучела)
- Систему отображения урона
- Направленное применение техник

---

## 🎮 Управление персонажем

### Направление взгляда

Персонаж имеет 8 направлений (или 360° плавное вращение):

```
        N (0°)
    NW      NE
  (315°)  (45°)
W (270°)  ●  E (90°)
  (225°)  (135°)
    SW      SE
        S (180°)
```

### Элементы управления

| Клавиша | Действие |
|---------|----------|
| W/A/S/D | Движение |
| Мышь / Колёсико | Вращение персонажа |
| 1-9 | Быстрый выбор техники |
| ЛКМ / Пробел | Применить технику |
| Tab | Меню техник |
| Shift | Ускоренное движение |

### Реализация вращения

```typescript
interface PlayerState {
  x: number;
  y: number;
  rotation: number;      // Угол в градусах (0-360)
  direction: Direction;  // 8 направлений для анимации
  isMoving: boolean;
  currentTechnique: string | null;
}

// Направления для спрайтов
type Direction = 'N' | 'NE' | 'E' | 'SE' | 'S' | 'SW' | 'W' | 'NW';

// Конвертация угла в направление
function angleToDirection(angle: number): Direction {
  const normalized = ((angle % 360) + 360) % 360;
  if (normalized >= 337.5 || normalized < 22.5) return 'N';
  if (normalized >= 22.5 && normalized < 67.5) return 'NE';
  if (normalized >= 67.5 && normalized < 112.5) return 'E';
  if (normalized >= 112.5 && normalized < 157.5) return 'SE';
  if (normalized >= 157.5 && normalized < 202.5) return 'S';
  if (normalized >= 202.5 && normalized < 247.5) return 'SW';
  if (normalized >= 247.5 && normalized < 292.5) return 'W';
  return 'NW';
}
```

---

## 🎯 Мишени (Соломенные чучела)

### Характеристики мишени

```typescript
interface TrainingTarget {
  id: string;
  x: number;
  y: number;
  hp: number;              // Текущее HP
  maxHp: number;           // Максимум HP (по умолчанию 1000)
  armor: number;           // Броня (0 для соломенного чучела)
  name: string;            // "Соломенное чучело"
  type: 'training_dummy';
  
  // Визуальное состояние
  hitEffect?: {
    timer: number;         // Время эффекта попадания
    lastDamage: number;    // Последний урон
  };
}
```

### Визуальное представление

```
      ╭───╮
      │ ○ │  ← Голова (солома)
      ╰─┬─╯
       ╱│╲   ← Тело
      ╱ │ ╲
     ╱  │  ╲
    ────┴────
    ║  ││  ║  ← Стойка
    ║  ││  ║
```

### Цветовые состояния

| HP % | Цвет | Описание |
|------|------|----------|
| 100-75% | 🟢 Зелёный | Невредимо |
| 75-50% | 🟡 Жёлтый | Лёгкие повреждения |
| 50-25% | 🟠 Оранжевый | Средние повреждения |
| 25-1% | 🔴 Красный | Сильные повреждения |
| 0% | ⚫ Серый | Уничтожено |

---

## 💥 Система отображения урона

### Всплывающие числа

При попадании по мишени появляется всплывающее число:

```typescript
interface DamageNumber {
  id: string;
  x: number;              // Позиция X
  y: number;              // Позиция Y (начальная)
  targetY: number;        // Целевая Y (для анимации)
  damage: number;         // Число урона
  type: DamageType;       // Тип для цвета
  alpha: number;          // Прозрачность (1 → 0)
  scale: number;          // Масштаб (1.5 → 1 → 0)
  lifetime: number;       // Время жизни (мс)
}

type DamageType = 
  | 'normal'    // Белый
  | 'critical'  // Красный, крупнее
  | 'blocked'   // Серый
  | 'healing'   // Зелёный
  | 'elemental';// Цвет элемента
```

### Анимация всплытия

```
Кадр 1:  [150] ← Появляется над мишенью
Кадр 30:   [150]  ← Поднимается вверх
Кадр 60:     [150] ← Начинает исчезать
Кадр 90:          ← Исчезает
```

### Цвета по типу

| Тип | Цвет | CSS |
|-----|------|-----|
| Normal | Белый | `#FFFFFF` |
| Critical | Красный | `#FF4444` |
| Blocked | Серый | `#888888` |
| Healing | Зелёный | `#44FF44` |
| Fire | Оранжевый | `#FF8844` |
| Water | Голубой | `#4488FF` |
| Earth | Коричневый | `#886644` |
| Air | Светло-серый | `#CCCCCC` |
| Lightning | Жёлтый | `#FFFF44` |

---

## ⚔️ Применение техник по направлению

### Конус поражения

Техники применяются в направлении взгляда персонажа:

```
          Направление взгляда
                ↓
    ┌───────────●───────────┐
    │        ╱     ╲        │
    │      ╱         ╲      │
    │    ╱   Радиус    ╲    │
    │  ╱     техники     ╲  │
    │╱                     ╲│
    ●───────────────────────●
    ↑                        ↑
    Край зоны               Край зоны
    
    Угол конуса зависит от техники
```

### Параметры направленности

```typescript
interface TechniqueDirection {
  type: 'cone' | 'line' | 'projectile' | 'self';
  
  // Для cone
  coneAngle?: number;      // Угол конуса (градусы)
  range: number;           // Дальность (метры → пиксели)
  
  // Для projectile
  projectileSpeed?: number; // Скорость снаряда (пиксели/сек)
  
  // Для line (луч)
  width?: number;          // Ширина луча
}
```

### Определение попадания

```typescript
function isInAttackCone(
  attacker: { x: number; y: number; rotation: number },
  target: { x: number; y: number },
  coneAngle: number,
  range: number
): boolean {
  // Вектор от атакующего к цели
  const dx = target.x - attacker.x;
  const dy = target.y - attacker.y;
  const distance = Math.sqrt(dx * dx + dy * dy);
  
  // Проверка дальности
  if (distance > range) return false;
  
  // Угол к цели
  const angleToTarget = Math.atan2(dy, dx) * 180 / Math.PI;
  const normalizedTarget = ((angleToTarget % 360) + 360) % 360;
  
  // Угол взгляда атакующего
  const normalizedAttacker = ((attacker.rotation % 360) + 360) % 360;
  
  // Разница углов
  let angleDiff = Math.abs(normalizedTarget - normalizedAttacker);
  if (angleDiff > 180) angleDiff = 360 - angleDiff;
  
  // Внутри конуса?
  return angleDiff <= coneAngle / 2;
}
```

---

## 🎨 Визуализация персонажа

### Спрайт персонажа (8 направлений)

Для каждого направления нужен отдельный спрайт:

```
┌─────┐  ┌─────┐  ┌─────┐
│  ↑  │  │ ↗  │  │  →  │
│  ●  │  │ ●  │  │  ●  │
│ /│\ │  │/│  │  │ /│\ │
│ / \ │  │/ \ │  │ / \ │
└─────┘  └─────┘  └─────┘
  N        NE       E

┌─────┐  ┌─────┐  ┌─────┐
│  ↓  │  │ ↙  │  │  ←  │
│  ●  │  │ ●  │  │●   │
│ /│\ │  │  │\ │  │ /│\ │
│ / \ │  │ / \ │  │ / \ │
└─────┘  └─────┘  └─────┘
  S        SW       W
```

### Программная генерация (без ассетов)

```typescript
function createPlayerSprite(
  graphics: Phaser.GameObjects.Graphics,
  direction: Direction,
  color: number = 0x4ade80
): Phaser.Textures.CanvasTexture {
  
  const size = 48;
  const cx = size / 2;
  const cy = size / 2;
  
  graphics.clear();
  
  // Тело (круг)
  graphics.fillStyle(color);
  graphics.fillCircle(cx, cy, 16);
  
  // Направление (стрелка/треугольник)
  graphics.fillStyle(0xFFFFFF);
  
  const angle = directionToAngle(direction);
  const rad = angle * Math.PI / 180;
  
  const tx = cx + Math.cos(rad) * 20;
  const ty = cy + Math.sin(rad) * 20;
  
  // Рисуем указатель направления
  graphics.fillTriangle(
    tx, ty,
    tx - 6 * Math.cos(rad - 0.5), ty - 6 * Math.sin(rad - 0.5),
    tx - 6 * Math.cos(rad + 0.5), ty - 6 * Math.sin(rad + 0.5)
  );
  
  return graphics.generateTexture(`player_${direction}`, size, size);
}
```

### Анимация движения

При движении персонаж слегка покачивается:

```typescript
// В update()
if (isMoving) {
  const bobAmount = Math.sin(Date.now() / 100) * 2;
  playerSprite.y += bobAmount;
}
```

---

## 🗺️ Расположение на полигоне

### Структура тестового уровня

```
┌────────────────────────────────────────────────────────────┐
│                                                            │
│    ┌───┐          ┌───┐          ┌───┐                    │
│    │ T │          │ T │          │ T │   ← Мишени         │
│    └───┘          └───┘          └───┘                    │
│                                                            │
│                     ●                                      │
│                    /|\   ← Игрок                           │
│                    / \                                     │
│                                                            │
│    ┌───┐          ┌───┐          ┌───┐                    │
│    │ T │          │ T │          │ T │                     │
│    └───┘          └───┘          └───┘                    │
│                                                            │
│  ═════════════════════════════════════════════════════════│
│  │ Техники: [1] Удар  [2] Снаряд  [3] Блок │              │
│  ═════════════════════════════════════════════════════════│
│                                                            │
└────────────────────────────────────────────────────────────┘
```

### Координаты мишеней

```typescript
const TARGET_POSITIONS = [
  { x: 200, y: 150 },
  { x: 400, y: 150 },
  { x: 600, y: 150 },
  { x: 200, y: 400 },
  { x: 400, y: 400 },
  { x: 600, y: 400 },
];
```

---

## 🔧 Техническая реализация

### Новые файлы

```
src/
├── game/
│   └── scenes/
│       └── TrainingGroundScene.ts  ← Новая сцена полигона
├── game/
│   └── objects/
│       ├── Player.ts               ← Класс игрока с вращением
│       └── TrainingTarget.ts       ← Класс мишени
└── components/game/
    └── DamageNumber.tsx            ← Компонент всплывающего урона
```

### Изменяемые файлы

```
src/
├── components/game/
│   └── PhaserGame.tsx              ← Интеграция новой сцены
└── stores/
    └── game.store.ts               ← Добавить rotation, targets
```

---

## 📐 Масштаб

1 метр = 32 пикселя (стандарт для 2D игр)

| Параметр | Метры | Пиксели |
|----------|-------|---------|
| Размер мишени | 1м | 32×32 |
| Радиус melee | 2м | 64px |
| Дальность снаряда | 30м | 960px |
| Скорость игрока | 5м/с | 160px/с |

---

## 🎯 Этапы реализации

### Этап 1: Персонаж с вращением
- [ ] Добавить rotation в состояние игрока
- [ ] Управление мышью/клавишами для вращения
- [ ] Генерация спрайтов для 8 направлений

### Этап 2: Мишени
- [ ] Создать класс TrainingTarget
- [ ] Разместить 6 мишеней на полигоне
- [ ] Визуальное отображение HP

### Этап 3: Урон и числа
- [ ] Система всплывающих чисел
- [ ] Анимация появления/исчезания
- [ ] Цвета по типу урона

### Этап 4: Направленные техники
- [ ] Конус поражения
- [ ] Проверка попадания
- [ ] Интеграция с combat-system.ts

---

## 🔗 Связанные документы

- [docs/COMBAT_TECHNIQUES_SYSTEM.md](./COMBAT_TECHNIQUES_SYSTEM.md) — Система боевых техник
- [src/lib/game/combat-system.ts](../src/lib/game/combat-system.ts) — Функции расчёта
- [docs/PHASER_STACK.md](./PHASER_STACK.md) — Стек Phaser 3

---

*Документ создан: 2026-02-12*
