# 💎 Концепция Камней Ци (Qi Stones)

**Версия:** 2.0  
**Создано:** 2026-02-28  
**Обновлено:** 2026-03-01  
**Статус:** Утверждено

---

## ⚠️ ВАЖНОЕ УТОЧНЕНИЕ

**Лор (`start_lore.md`) первичен!** В Лоре нет понятия "качество" камней Ци.

Камень Ци характеризуется только:
1. **Объёмом Ци** (ед)
2. **Типом Ци** (спокойная / хаотичная)

---

## 📋 Обзор

Камни Ци (Духовные Камни) — твёрдая форма Ци, естественным образом кристаллизующаяся при высокой концентрации Ци в замкнутых пространствах.

### Физика агрегатных состояний Ци

Ци — магическая субстанция с особыми свойствами фазовых переходов:

1. **Газообразное состояние** — Ци в окружающей среде
   - Максимальная плотность: **10 000 ед/м³**
   - При превышении → резкий переход в сверхкритическое состояние
   - Аналог "насыщенного пара"

2. **Твёрдое состояние** — кристаллы Ци (камни духа)
   - Плотность: **1 024 ед/см³** = **1 024 000 000 ед/м³**
   - В 102 400 раз плотнее газа
   - Удерживается "давлением паров" — внутренней силой кристалла

3. **Сверхкритическое состояние** — плазма при использовании техник
   - Промежуточная фаза между газом и жидкостью
   - Плотность как у жидкой Ци практика

**Ключевой принцип:** Даже при огромной плотности твёрдой Ци, внутреннее давление паров (ρ_равн = 1 024 000 ед/м³) сдерживает её от быстрого испарения. Камни Ци условно стабильны.

### В мире

```
┌─────────────────────────────────────────────────────────────────────────┐
│                      АГРЕГАТНЫЕ СОСТОЯНИЯ ЦИ                             │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│   ГАЗ (в среде)          ПЛАЗМА (техники)        ЖИДКОСТЬ (тело)         │
│   ≤ 10 000 ед/м³         сверхкритическая        Qi(x) = 2^(L-1) ед/см³ │
│         ↓                      ↓                       ↓               │
│         └──────────────────────┴───────────────────────┘               │
│                                 ↓                                       │
│                        ТВЁРДОЕ ТЕЛО (кристаллы)                         │
│                        1 024 ед/см³ = 1 024 000 000 ед/м³              │
│                                                                          │
│   ┌─────────────────────────────────────────────────────────────────┐   │
│   │                 ПЛОТНОСТЬ (единый базис)                        │   │
│   │                                                                  │   │
│   │   Газ:        10 000 ед/м³      = 0.01 ед/см³                   │   │
│   │   Qi(1):            1 ед/см³    = 100x газ                       │   │
│   │   Qi(5):           16 ед/см³    = 1 600x газ                     │   │
│   │   Qi(9):          256 ед/см³    = 25 600x газ                    │   │
│   │   Кристалл:    1 024 ед/см³    = 102 400x газ                    │   │
│   │                                                                  │   │
│   └─────────────────────────────────────────────────────────────────┘   │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 1️⃣ ФИЗИКА КРИСТАЛЛОВ ЦИ

### 1.1 Образование

```typescript
interface QiCrystalFormation {
  // Условия образования
  conditions: {
    minQiDensity: number;       // > 10 000 ед/м³ (превышение капа)
    enclosedSpace: boolean;     // Замкнутое пространство
    stabilityTime: number;      // Время стабильности (часы)
  };
  
  // Скорость кристаллизации
  crystallizationRate: {
    formula: 'излишки_Ци / время';
    typicalRate: '10% излишков в час';
  };
  
  // Форма
  shape: {
    natural: 'cubic';           // Естественная форма — куб
    crafted: 'any';             // Можно обработать
  };
}
```

### 1.2 Структура кристалла

```typescript
interface QiCrystalStructure {
  // === БАЗОВЫЕ ПАРАМЕТРЫ ===
  density: 1024;                // ед/см³ (постоянная)
  
  // === РАЗМЕРЫ ===
  size: {
    side: number;               // Длина стороны (см) — для куба
    volume: number;             // Объём (см³)
    surface: number;            // Площадь поверхности (см²)
  };
  
  // === СОДЕРЖАНИЕ ЦИ ===
  qiContent: {
    total: number;              // Общее количество Ци (ед)
    formula: '1024 × объём_см³';
  };
  
  // === СТАБИЛЬНОСТЬ ===
  stability: {
    equilibriumDensity: number; // Равновесная плотность окружения
    evaporationRate: number;    // Скорость испарения (ед/час)
  };
}
```

### 1.3 Классификация по размеру

```typescript
type QiStoneSize = 
  | 'dust'       // Пыль (< 0.1 см³)
  | 'fragment'   // Осколок (0.1 - 1 см³)
  | 'small'      // Малый (1 - 8 см³)
  | 'medium'     // Средний (8 - 27 см³)
  | 'large'      // Большой (27 - 64 см³)
  | 'huge'       // Огромный (64 - 125 см³)
  | 'boulder';   // Глыба (> 125 см³)

interface QiStoneSizeData {
  name: string;
  volumeRange: [number, number];  // см³
  qiRange: [number, number];      // ед Ци
  typicalDimensions: string;
}

const QI_STONE_SIZES: Record<QiStoneSize, QiStoneSizeData> = {
  dust: {
    name: 'Пыль Ци',
    volumeRange: [0, 0.1],
    qiRange: [0, 102],
    typicalDimensions: '< 0.5 мм',
  },
  fragment: {
    name: 'Осколок Ци',
    volumeRange: [0.1, 1],
    qiRange: [102, 1024],
    typicalDimensions: '0.5 - 1 см',
  },
  small: {
    name: 'Малый камень',
    volumeRange: [1, 8],
    qiRange: [1024, 8192],
    typicalDimensions: '1 - 2 см',
  },
  medium: {
    name: 'Средний камень',
    volumeRange: [8, 27],
    qiRange: [8192, 27648],
    typicalDimensions: '2 - 3 см',
  },
  large: {
    name: 'Большой камень',
    volumeRange: [27, 64],
    qiRange: [27648, 65536],
    typicalDimensions: '3 - 4 см',
  },
  huge: {
    name: 'Огромный камень',
    volumeRange: [64, 125],
    qiRange: [65536, 128000],
    typicalDimensions: '4 - 5 см',
  },
  boulder: {
    name: 'Глыба Ци',
    volumeRange: [125, Infinity],
    qiRange: [128000, Infinity],
    typicalDimensions: '> 5 см',
  },
};
```

---

## 2️⃣ ТИПЫ КАМНЕЙ ЦИ

### 2.1 По типу Ци (ЕДИНСТВЕННАЯ КЛАССИФИКАЦИЯ)

```typescript
type QiStoneType = 
  | 'calm'       // Спокойная Ци (стандарт)
  | 'chaotic';   // Хаотичная Ци (опасна, высокая энергия)

// ПРИМЕЧАНИЕ: При конденсации Ци теряет все свойства и становится нейтральной.
// Камни Ци всегда содержат только спокойную или хаотичную Ци.
// Стихийные камни и настройка на практика — не реализованы в данной системе.

interface QiStoneTypeData {
  name: string;
  description: string;
  qiType: 'calm' | 'chaotic';
  specialProperties: string[];
  danger: number;               // Уровень опасности (0-10)
}

const QI_STONE_TYPES: Record<QiStoneType, QiStoneTypeData> = {
  calm: {
    name: 'Камень спокойной Ци',
    description: 'Стандартный кристалл, безопасен для поглощения.',
    qiType: 'calm',
    specialProperties: ['stable', 'predictable'],
    danger: 0,
  },
  chaotic: {
    name: 'Камень хаотичной Ци',
    description: 'Содержит неупорядоченную Ци. Высокий энергетический потенциал, но опасен.',
    qiType: 'chaotic',
    specialProperties: ['unstable', 'high_energy', 'dangerous'],
    danger: 7,
  },
};
```

### ~~2.2 По качеству (УДАЛЕНО)~~

> ⚠️ **Удалено в v2.0** — Лор не предусматривает качество камней.
> 
> Камень Ци характеризуется только объёмом Ци и типом.

---

## 3️⃣ МЕХАНИКА ПОГЛОЩЕНИЯ

### 3.1 Процесс поглощения

```typescript
interface QiAbsorption {
  // === ИСТОЧНИК ===
  source: {
    stone: QiStone;
    availableQi: number;        // Доступная Ци
    releaseRate: number;        // Скорость высвобождения (ед/сек)
  };
  
  // === КАНАЛ (меридианы практика) ===
  channel: {
    conductivity: number;       // Проводимость меридиан (ед/сек)
    currentLoad: number;        // Текущая нагрузка
    maxCapacity: number;        // Макс. ёмкость буфера
  };
  
  // === ПРИЁМНИК (ядро практика) ===
  receiver: {
    coreCapacity: number;       // Ёмкость ядра
    currentQi: number;          // Текущее Ци
    freeSpace: number;          // Свободное место
    qiDensity: number;          // Плотность Ци в ядре
  };
  
  // === РЕЗУЛЬТАТ ===
  result: {
    effectiveRate: number;      // Эффективная скорость
    bottleneck: 'source' | 'channel' | 'receiver'; // Узкое место
    timeToFull: number;         // Время до заполнения (сек)
  };
}
```

### 3.2 Ограничения скорости

```typescript
// "Нельзя вылить бассейн за секунды через трубочку для коктейлей"

function calculateAbsorptionRate(
  stone: QiStone,
  practitioner: Character
): AbsorptionRateResult {
  // 1. Скорость высвобождения из камня (зависит от размера поверхности)
  const stoneSurface = stone.size.surface; // см²
  const stoneReleaseRate = stoneSurface * 0.5; // 0.5 ед/(см²·сек)
  
  // 2. Пропускная способность меридиан
  const meridianThroughput = practitioner.conductivity; // ед/сек
  
  // 3. Свободное место в ядре
  const coreFreeSpace = practitioner.coreCapacity - practitioner.currentQi;
  
  // 4. Эффективная скорость = минимум из трёх
  const effectiveRate = Math.min(
    stoneReleaseRate,
    meridianThroughput,
    coreFreeSpace > 0 ? Infinity : 0 // Если ядро полное - 0
  );
  
  // 5. Определение узкого места
  let bottleneck: 'source' | 'channel' | 'receiver';
  if (coreFreeSpace <= 0) {
    bottleneck = 'receiver';
  } else if (meridianThroughput < stoneReleaseRate) {
    bottleneck = 'channel'; // Меридианы - "трубочка"
  } else {
    bottleneck = 'source';
  }
  
  return {
    effectiveRate,
    stoneReleaseRate,
    meridianThroughput,
    bottleneck,
    canAbsorb: coreFreeSpace > 0,
    timeToFullCore: coreFreeSpace > 0 ? coreFreeSpace / effectiveRate : 0,
  };
}

// Примеры:
// Камень 10 см³ = 10 240 ед Ци
// Проводимость 2.0 ед/сек = 7200 ед/час
// Время поглощения: 10 240 / 7200 ≈ 1.4 часа

// Камень 100 см³ = 102 400 ед Ци
// Проводимость 5.0 ед/сек = 18 000 ед/час
// Время поглощения: 102 400 / 18 000 ≈ 5.7 часов
```

### 3.3 Формула испарения

```typescript
// === ФИЗИКА ЦИ: АГРЕГАТНЫЕ СОСТОЯНИЯ ===
//
// Ци — магическая субстанция с особыми свойствами:
//
// 1. ГАЗООБРАЗНОЕ СОСТОЯНИЕ (в окружающей среде):
//    - Максимальная плотность: 10 000 ед/м³
//    - При превышении → резкий переход в сверхкритическое состояние
//    - Это "насыщенный пар" Ци
//
// 2. ТВЁРДОЕ СОСТОЯНИЕ (кристаллы Ци):
//    - Плотность: 1 024 ед/см³ = 1 024 000 000 ед/м³
//    - В 102 400 раз плотнее газа
//    - Удерживается "давлением паров" — внутренней силой кристалла
//
// 3. ПЕРЕХОДЫ:
//    - Газ → Кристалл: при превышении 10 000 ед/м³ в замкнутом объёме
//    - Кристалл → Газ: испарение при низкой плотности окружения
//
// === ФОРМУЛА ИСПАРЕНИЯ ===
//
// Из start_lore.md (контейнер 4):
// ρ_крист = 1.024×10⁹ ед/м³ (1024 ед/см³)
// k = 0.001
// ρ_равн = k × ρ_крист = 1 024 000 ед/м³ — "давление паров" кристалла
// α = G / ρ_равн
// Q_испар = α × S_крист × (ρ_равн - ρ_окр)
//
// ВАЖНО: ρ_равн ≠ максимальной плотности газа!
// ρ_равн — это параметр кристалла, его "удерживающая сила".
// Даже при огромной плотности твёрдой Ци, внутреннее давление паров
// сдерживает её от испарения.
//
// Камень стабилен когда ρ_окр → ρ_равн (в специальных условиях).
// В обычной среде (ρ_окр ≤ 10 000 ед/м³) камень очень медленно испаряется.

function calculateEvaporationRate(
  stone: QiStone,
  environmentQiDensity: number, // ед/м³ (0 ≤ ρ_окр ≤ 10 000)
  flowRate: number              // G — скорость истечения Ци местности (ед/ч·м²)
): number {
  const rho_crystal = 1024e6;    // 1 024 000 000 ед/м³ — плотность кристалла
  const k = 0.001;               // Коэффициент
  const rho_vaporPressure = k * rho_crystal; // 1 024 000 ед/м³ — "давление паров"
  
  const surfaceArea = stone.size.surface / 10000; // см² → м²
  
  // Коэффициент испарения
  const alpha = flowRate / rho_vaporPressure;
  
  // Скорость испарения (ед/час)
  // Чем выше плотность окружения, тем медленнее испарение
  const evaporationRate = alpha * surfaceArea * (rho_vaporPressure - environmentQiDensity);
  
  return Math.max(0, evaporationRate);
}

// Примеры:
// Камень 8 см³, поверхность 24 см² = 0.0024 м²
// G = 10 ед/ч·м² (типичная местность)
// α = 10 / 1 024 000 ≈ 0.00000977
// При ρ_окр = 5 000 ед/м³:
// Q_испар = 0.00000977 × 0.0024 × (1 024 000 - 5 000) ≈ 0.024 ед/час
//
// Это очень медленное испарение — камень на 8192 ед Ци "продержится"
// около 8192 / 0.024 ≈ 341 333 часов ≈ 39 лет
// (в реальности испарение ещё медленнее из-за изоляции при хранении)
```

---

## 4️⃣ ИСПОЛЬЗОВАНИЕ

### 4.1 Способы поглощения

```typescript
type AbsorptionMethod = 
  | 'direct'     // Прямое поглощение (камень в руке)
  | 'meditation' // Медитация с камнем
  | 'charger';   // Через зарядник (отдельный документ)

interface AbsorptionMethodData {
  name: string;
  description: string;
  speedMultiplier: number;
  requirements: string[];
  risks: string[];
}

const ABSORPTION_METHODS: Record<AbsorptionMethod, AbsorptionMethodData> = {
  direct: {
    name: 'Прямое поглощение',
    description: 'Практик держит камень в руке и вытягивает Ци напрямую.',
    speedMultiplier: 1.0,
    requirements: ['Свободная рука', 'Контакт с камнем'],
    risks: ['Возможна утечка Ци', 'Требуется концентрация'],
  },
  meditation: {
    name: 'Медитация с камнем',
    description: 'Камень помещается в формацию или рядом, Ци поглощается во время медитации.',
    speedMultiplier: 1.5, // Быстрее через формацию
    requirements: ['Медитация', 'Формация (опционально)'],
    risks: ['Прерывание медитации'],
  },
  charger: {
    name: 'Через зарядник',
    description: 'Камень вставляется в специальное устройство для контролируемого поглощения.',
    speedMultiplier: 2.0,
    requirements: ['Зарядник', 'Слот для камня'],
    risks: ['Минимальные'],
  },
};
```

### 4.2 Обработка камней

```typescript
interface QiStoneCrafting {
  // === ГРАНКА (разделение) ===
  cutting: {
    process: 'Разделение на части';
    conservation: '95-99% Ци сохраняется';
    useCase: 'Создание камней нужного размера';
  };
  
  // === СИНТЕЗ (объединение) ===
  synthesis: {
    process: 'Объединение мелких камней';
    conservation: '90% Ци сохраняется';
    useCase: 'Создание крупных камней';
    requirement: 'Камни одного типа (calm/chaotic)';
  };
}
```

---

## 5️⃣ ЭКОНОМИКА

### 5.1 Стандартные цены

```typescript
// Базовая единица = 1 ед Ци = 0.01 духовного камня

interface QiStonePricing {
  // Цена за ед Ци
  pricePerQiUnit: 0.01; // духовных камней
  
  // Множитель за размер (крупные камни ценнее)
  sizeMultipliers: {
    dust: 0.5,      // Пыль дешевле (сложно собрать)
    fragment: 0.8,
    small: 1.0,     // Стандарт
    medium: 1.2,
    large: 1.5,
    huge: 2.0,
    boulder: 3.0,   // Редкость
  };
  
  // Множитель за тип
  typeMultipliers: {
    calm: 1.0,
    chaotic: 2.0,   // Опасность = ценность для смелых
  };
}

// Примеры:
// Малый камень (8192 ед Ци) = 8192 × 0.01 × 1.0 = 81.92 дк
// Средний камень (20000 ед) × 1.2 = 240 дк
// Глыба (200000 ед) × 3.0 = 6000 дк
// Хаотичный камень × 2.0 (дороже из-за опасности)
```

### 5.2 Использование как валюты

```typescript
// В мире культивации духовные камни = твёрдая валюта

interface QiStoneAsCurrency {
  // Стандартные номиналы
  denominations: {
    'qi_dust': { value: 1, name: 'Пыль Ци' },           // ~1 ед Ци
    'low_stone': { value: 100, name: 'Низкосортный' },  // ~100 ед Ци
    'medium_stone': { value: 500, name: 'Средний' },    // ~500 ед Ци
    'high_stone': { value: 2000, name: 'Высокосортный' },// ~2000 ед Ци
  };
  
  // Обмен
  exchange: {
    dustToLow: 100,      // 100 пыли = 1 низкосортный
    lowToMedium: 5,      // 5 низкосортных = 1 средний
    mediumToHigh: 4,     // 4 средних = 1 высокосортный
  };
  
  // Физическое представление
  physical: {
    dust: 'Мешочек пыли',
    low: 'Камень ~1 см³',
    medium: 'Камень ~2 см³',
    high: 'Камень ~4 см³',
  };
}
```

---

## 6️⃣ ОПАСНОСТИ

### 6.1 Риски при поглощении

```typescript
interface QiStoneDangers {
  // === ПЕРЕНАСЫЩЕНИЕ ===
  oversaturation: {
    cause: 'Слишком быстрое поглощение';
    effect: 'Повреждение меридиан';
    symptoms: ['Боль', 'Снижение проводимости', 'Возможный разрыв каналов'];
    prevention: 'Не превышать пропускную способность меридиан';
    formula: 'effectiveRate ≤ conductivity';
  };
  
  // === ХАОТИЧНАЯ ЦИ ===
  chaoticQi: {
    cause: 'Поглощение камня хаотичной Ци';
    effect: 'Накопление хаотичной Ци в ядре';
    symptoms: ['Нестабильность', 'Снижение эффективности техник', 'Риск отравления'];
    treatment: 'Длительная медитация на успокоение';
    risk: 'Высокий энергетический потенциал, но опасен';
  };
}
```

### 6.2 Обращение и хранение

```typescript
interface QiStoneHandling {
  // === ХРАНЕНИЕ ===
  storage: {
    environment: 'Герметичный контейнер из изолирующего материала';
    isolation: 'Дерево, керамика, кость - не проводят Ци';
    stacking: 'Избегать контакта камней (резонанс)';
    degradation: 'В обычных условиях камень медленно испаряется';
  };
  
  // === ТРАНСПОРТИРОВКА ===
  transport: {
    container: 'Изолирующая сумка или короб';
    shielding: 'Слой изолирующего материала';
    proximity: 'Не носить близко к ядру без защиты';
  };
  
  // === ЗАЩИТА ===
  security: {
    theft: 'Камни легко украсть (малый размер, высокая ценность)';
    detection: 'Высокая концентрация Ци заметна для культиваторов';
    sealing: 'Можно запечатать камень (техника, формация)';
  };
}
```

---

## 7️⃣ ИНТЕГРАЦИЯ С СИСТЕМОЙ

### 7.1 Структура данных

```typescript
interface QiStone {
  // === ИДЕНТИФИКАЦИЯ ===
  id: string;                 // QS_XXXXXX
  name: string;
  description: string;
  
  // === ФИЗИЧЕСКИЕ ПАРАМЕТРЫ ===
  size: {
    side: number;             // см (для куба)
    volume: number;           // см³
    surface: number;          // см²
    sizeClass: QiStoneSize;
  };
  
  // === ТИП ЦИ (ЕДИНСТВЕННЫЙ) ===
  type: QiStoneType;          // 'calm' | 'chaotic'
  
  // === СОДЕРЖАНИЕ ЦИ ===
  qiContent: {
    total: number;            // ед Ци
    current: number;          // Текущее (после частичного использования)
    density: 1024;            // ед/см³ (постоянная)
  };
  
  // === СВОЙСТВА (вычисляемые) ===
  properties: {
    releaseRate: number;      // ед/сек (зависит от поверхности)
  };
  
  // === СОСТОЯНИЕ ===
  state: {
    isSealed: boolean;
    sealStrength?: number;
  };
  
  // === СТОИМОСТЬ ===
  baseValue: number;          // Духовные камни
}
```

### 7.2 Prisma Schema

```prisma
model QiStone {
  id          String   @id @default(cuid())
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  
  // === ИДЕНТИФИКАЦИЯ ===
  name        String
  description String
  
  // === РАЗМЕР ===
  sideCm      Float    // Длина стороны (см)
  volumeCm3   Float    // Объём (см³)
  surfaceCm2  Float    // Площадь поверхности (см²)
  sizeClass   String   // dust, fragment, small, medium, large, huge, boulder
  
  // === ТИП ЦИ ===
  stoneType   String   // calm, chaotic
  
  // === СОДЕРЖАНИЕ ЦИ ===
  totalQi     Int      // Полное содержание (ед)
  currentQi   Int      // Текущее содержание (ед)
  
  // === СВОЙСТВА ===
  releaseRate Float    // Скорость высвобождения (ед/сек)
  
  // === СОСТОЯНИЕ ===
  isSealed    Boolean  @default(false)
  sealStrength Int?
  
  // === СТОИМОСТЬ ===
  baseValue   Int      // Базовая стоимость (духовные камни)
  
  // === СВЯЗИ ===
  characterId String?
  character   Character? @relation(fields: [characterId], references: [id])
  
  // Для зарядника
  chargerId   String?
  
  @@map("qi_stones")
}
```

---

## 8️⃣ ПРИМЕРЫ

### 8.1 Стандартный малый камень

```yaml
qi_stone:
  id: "QS_000042"
  name: "Малый камень Ци"
  description: "Стандартный кристалл для практики культивации."
  
size:
  side: 2.0                    # 2 см
  volume: 8.0                   # 8 см³
  surface: 24.0                 # 24 см²
  sizeClass: small

type: calm

qiContent:
  total: 8192                   # 1024 × 8
  current: 8192

properties:
  releaseRate: 12.0             # 24 см² × 0.5 ед/(см²·сек)

state:
  isSealed: false

baseValue: 82                   # 8192 × 0.01 духовных камней
```

### 8.2 Камень хаотичной Ци

```yaml
qi_stone:
  id: "QS_000103"
  name: "Нестабильный кристалл"
  description: "Кристалл с высоким содержанием хаотичной Ци. Опасен для неопытных практиков."
  
size:
  side: 2.5                     # ~2.5 см
  volume: 15.625                 # ~15.6 см³
  surface: 37.5                  # см²
  sizeClass: medium

type: chaotic

qiContent:
  total: 16000                   # 1024 × 15.625
  current: 16000

properties:
  releaseRate: 18.75             # ед/сек

state:
  isSealed: true
  sealStrength: 3                # Запечатан для безопасности

baseValue: 375                   # 16000 × 0.01 × 1.2 × 2.0 (хаотичный)
```

### 8.3 Большой камень

```yaml
qi_stone:
  id: "QS_000501"
  name: "Сокровище древнего мастера"
  description: "Крупный кристалл, обработанный мастерами древности."
  
size:
  side: 3.5
  volume: 42.875                 # ~43 см³
  surface: 73.5
  sizeClass: large

type: calm

qiContent:
  total: 43878                   # 1024 × 42.875
  current: 43878

properties:
  releaseRate: 36.75             # ед/сек

state:
  isSealed: true
  sealStrength: 7                # Мощная защита

baseValue: 658                   # 43878 × 0.01 × 1.5 (large)
```

---

## 🔗 Связанные документы

- [equip.md](./equip.md) — Система экипировки
- [body.md](./body.md) — Концепция тела
- [start_lore.md](./start_lore.md) — Лор мира (контейнер 4)
- [checkpoint29.md](./checkpoint29.md) — План реализации

---

## 📝 История изменений

| Версия | Дата | Изменения |
|--------|------|-----------|
| 2.0 | 2026-03-01 | Удалено понятие "качество" (Лор первичен). Упрощена структура. |
| 1.0 | 2026-02-28 | Первоначальная версия |

---

*Документ создан: 2026-02-28*  
*Обновлён: 2026-03-01*
