# 🎮 Чит-команды (только development)

**Доступны в development режиме или с ENABLE_CHEATS=true**

## Уровень культивации
```
/cheat set_level {"level":5,"subLevel":3}  → Установить уровень 5.3
/cheat breakthrough                         → Мгновенный прорыв
```

## Ци и ресурсы
```
/cheat add_qi 1000         → Добавить 1000 Ци
/cheat set_qi 5000         → Установить Ци = 5000
/cheat full_restore        → Полное восстановление
/cheat add_resources {"points":100,"stones":50}
```

## Характеристики
```
/cheat add_stat {"stat":"strength","amount":10}  → +10 к силе
/cheat set_stat {"stat":"intelligence","value":50}  → Интеллект = 50
```

## Усталость
```
/cheat add_fatigue {"physical":20,"mental":10}  → Добавить усталость
/cheat reset_fatigue                            → Сбросить усталость
```

## Техники
```
/cheat give_technique {"techniqueId":"fire-palm"}  → Изучить технику
/cheat gen_techniques {"level":2,"count":5}        → Сгенерировать пул
```

## Прозрение
```
/cheat add_insight {"amount":50}  → +50 прозрения
```

## Камни Ци (Qi Stones)
```
/cheat add_qi_stone {"quality":"stone","quantity":3}  → Добавить Камни Ци
```
**Доступные качества:**
- `shard` - Осколок (50 Ци)
- `fragment` - Фрагмент (100 Ци)
- `stone` - Камень (200 Ци)
- `crystal` - Кристалл (500 Ци)
- `heart` - Сердце (1000 Ци)
- `core` - Ядро (2000 Ци)

## God Mode
```
/cheat god_mode  → Максимальные статы, бессмертие
```

## API Endpoints
- `GET /api/cheats` - Справка по командам
- `POST /api/cheats` - Выполнить команду
- `GET /api/techniques/pool?characterId=...` - Получить пул техник
- `POST /api/techniques/pool` - Сгенерировать пул
- `PUT /api/techniques/pool` - Выбрать/раскрыть технику

---
*Этот файл вынесен из .session-context для оптимизации*
*Обновлено: 2026-03-01*
